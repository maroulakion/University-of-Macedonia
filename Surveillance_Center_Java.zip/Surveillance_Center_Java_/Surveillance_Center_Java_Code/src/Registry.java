import java.util.ArrayList;

public class Registry {
	
	 ArrayList<Suspect> suspects; 
	 ArrayList<Communication> communications;
	 
	 // CONSTRUCTOR
	 public Registry () {
		suspects = new ArrayList<Suspect> ();
		communications = new ArrayList<Communication> ();
	 }
	 
	 // GETTERS
	 ArrayList<Suspect> getSuspects() {
		 return suspects;
	 }
	 
	 ArrayList<Communication> getCommunications() {
		 return communications;
	 }
	 
	 
	 //register a suspect
	 void addSuspect(Suspect aSuspect) {
		 suspects.add(aSuspect);
	 }
	 
	 // register a communication
	 // If communation spoted between phone Numbers Num1, Num2
	 // update theis partner's list
	 void addCommunication(Communication aCommunication) {
		 
		 //register communication
		 communications.add(aCommunication);

		 //update suspects' partners lists
		 for (Communication c : communications ) {
			 
			 // s1, s2 suspects involved in the 
			 // the "c" communication
			 Suspect s1 = null, s2 = null;
			 
			 for (Suspect s : suspects)
				 for (String num : s.getNumbers())
					 if ( (c.getPhone1()).equals(num) ) {
						 s1 = s;
						 break;
					 }
			 
			 for (Suspect s : suspects)
				 for (String num : s.getNumbers())
					 if ( (c.getPhone2()).equals(num) ) {
						 s2 = s;
						 break;
					 }
			//SET PRIMARY SUSPECTS
			// If connected and such connection is not registered already,
			//   create connection --> register them in the partner list
			if (!s1.isPartnerWith(s2))
				s1.getPartners().add(s2);
			if (!s2.isPartnerWith(s1))
				s2.getPartners().add(s1);
			
			//SET SUGGESTED SUSPECTS
			ArrayList<Suspect> commonPart = new ArrayList<Suspect>();
			commonPart = s1.getCommonPartners(s2);
			
			//for s1
			for (Suspect otherPart : s2.getPartners())
				if (!otherPart.existsOnList(commonPart))
					if (!otherPart.equals(s1))
						if (!otherPart.existsOnList(s1.getSuggPartners()))
							s1.getSuggPartners().add(otherPart);
			
			//for s2
			for (Suspect otherPart : s1.getPartners())
				if (!otherPart.existsOnList(commonPart))
					if (!otherPart.equals(s2))
						if (!otherPart.existsOnList(s2.getSuggPartners()))
							s2.getSuggPartners().add(otherPart);
			
			 
		 }		 
			 
	 }
	 
	 
	 // add triggering words to list
	 private void fillArrayManually(ArrayList<String> array) {
		 array.add("Bomb");
		 array.add("Attack");
		 array.add("Explosives");
		 array.add("Gun");
	 }
	 
	 
	 // returns all messages including triggering words
	 // list of triggering words : "Bomb", "Attack", "Explosives", "Gun"
	 ArrayList<SMS> getMessagesBetween(String number1, String number2) {
		 ArrayList<String> triggeringWords = new ArrayList<String>();
		 fillArrayManually(triggeringWords);
		 String[] words_in_text;
		 
		 ArrayList<SMS> textsWithTrigWords = new ArrayList<SMS>();
		 
		 for (Communication com : communications) {
			 
			 if (com instanceof SMS) {
				 if ((number1.equals(com.getPhone1()) && number2.equals(com.getPhone2()))
					  || (number2.equals(com.getPhone1()) && number1.equals(com.getPhone2()))) {
					 
					 words_in_text = ((SMS)com).getMessage().split(" ");
					 
					 for(String word : words_in_text) 
						 for (String trig_word : triggeringWords)
				 			 if (word.equals(trig_word))
								 textsWithTrigWords.add( (SMS)com );
				 }
			}
				 
		 }
				 
		 return textsWithTrigWords; 
	 }
	 
	 String getAllTrigMessagesWith(Suspect s, String otherNum) {
		 String allSMS = "";
		 for (String num : s.getNumbers()) {
			 ArrayList<SMS> textsWithTrigWords = new ArrayList<SMS>();
			 textsWithTrigWords = this.getMessagesBetween(num, otherNum);
			 for (SMS text : textsWithTrigWords) {
				 //System.out.println(text.getMessage());
				 allSMS = allSMS + text.getMessage() + "\n"; 
			 }
		 }
		 if (allSMS.equals(""))
			 allSMS = "-- no contacting --";
		 return allSMS;
	 }
	
}
