

public class PhoneCall extends Communication{
	
	private int duration;
	
	int getDuration() {
		return duration;
	}
	
	public PhoneCall (String phone1, String phone2, int day, int month, int year, int duration) {
		super(phone1, phone2, day, month, year);
		this.duration = duration;
	}
	
	
	@Override
	void printInfo() {
		System.out.println("This phone call has the following info");
		System.out.println("Between " + this.phone1 + " --- " + this.phone2);
		System.out.println("on "+this.getYear()+"/"+this.getMonth()+"/"+this.getDay());
		System.out.println("Duration: "+this.getDuration());
	}
			

	
}
