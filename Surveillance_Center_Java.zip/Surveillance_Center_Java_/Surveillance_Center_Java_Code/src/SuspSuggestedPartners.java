import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;


public class SuspSuggestedPartners {
	
	JPanel panel;
	JLabel title;
	JTextArea partnersArea;
	
	SuspSuggestedPartners(Suspect s) {
		
		// SET UP PANEL
		panel = new JPanel();
		panel.setBackground(new Color(113, 87, 70));
		panel.setBounds(20, 400, 600, 80);
		
		title = new JLabel("Suggested Partners");
		title.setForeground(Color.WHITE);
		title.setFont( new Font("Serif", Font.BOLD, 15));
		
		String allSugg = s.getAllSuggPartners();
		partnersArea = new JTextArea(allSugg);
		partnersArea.setPreferredSize(new Dimension(250, 70));
		
		panel.add(title);
		panel.add(partnersArea);
		
	}
}
