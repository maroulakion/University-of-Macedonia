import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class NotFoundFrame {
	
	private JFrame frame;
	private JLabel errorMsg;
	private ButtonReturnToHomeScreen confirmButton;
	
	NotFoundFrame(Suspect s, Registry registry) {
		
		//SET UP FRAME
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//  --> DISPOSE_ON_CLOSE: only destroy that frame, 
		//                        but do not terminate program
		frame.setSize(550,350);
		frame.setLayout(null);
		Color backColor = new Color(153, 236, 250);
		frame.getContentPane().setBackground(backColor);
		frame.setTitle("Message (not found)");
		
		// SET UP PANEL
		JPanel messagePanel = new JPanel();
		messagePanel.setBounds(50, 50, 450, 100);
		messagePanel.setBackground(backColor);
		
		JPanel buttonSpace = new JPanel();
		buttonSpace.setBackground(new Color(143, 216, 160));
		buttonSpace.setBounds(100, 150, 350, 40);
		
		// Create elements
		// 		label (error message)
		errorMsg = new JLabel("Suspect " + s.getName() + " not found");
		errorMsg.setFont(new Font("Garamond", Font.BOLD, 20));
		errorMsg.setForeground(new Color(113, 87, 90));
		
		messagePanel.add(errorMsg);
		// Add panel to frame
		frame.add(messagePanel);
		
		//		button (OK)
		confirmButton = new ButtonReturnToHomeScreen(frame, buttonSpace, registry);
		
		
		
		
		frame.setVisible(true);
		
	}
	
	JFrame getFrame() {
		return frame;
	}
	
	
}
