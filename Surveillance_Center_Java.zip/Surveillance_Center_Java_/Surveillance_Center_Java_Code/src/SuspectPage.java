import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SuspectPage {
	
	JFrame frame;
	JButton returnHome;
	JButton findButton;
	//JPanel generalInfo;
	//JPanel smsPanel;
	//JPanel partnersPanel;
	//JPanel suggPartnersPanel;
	//JPanel suspSameCountryPanel;
	
	Registry registry;
	
	SuspectPage(Suspect s, Registry reg) {
		
		registry = reg;
		
		// SET UP FRAME
		frame = new JFrame();
		frame.setTitle("Suspect Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(650, 800);
		frame.setLayout(null);
		frame.getContentPane().setBackground(new Color(193, 196, 220));
		//Container c=frame.getContentPane();
		
		// Create graphic elements
		//		1. GENERAL INFO PANEL
		GeneralInfo panel1 = new GeneralInfo(s);
		//		2. SMS PANEL
		TriggeringSMS panel2 = new TriggeringSMS(frame, s, registry);
		//		3. PARTNERS PANEL
		SuspectsPartners panel3 = new SuspectsPartners(s);
		//		4. SUGGESTED PARTNERS PANEL
		SuspSuggestedPartners panel4 = new SuspSuggestedPartners(s);
		//		5. SUSPECTS FROM THE SAME COUNTRY PANEL
		SuspFromSameCountry panel5 = new SuspFromSameCountry(s, registry);
		//		RETURN TO HOME SCREEN BUTTON
		JPanel panel6 = new JPanel();
		panel6.setBounds(190, 590, 260, 40);
		panel6.setBackground(new Color(102, 193, 137));
		ButtonReturnToHomeScreen returnHome = new ButtonReturnToHomeScreen(frame, panel6, registry);
		
		// Show frame on screen
		frame.setVisible(true);
		
		// ADD panels to frame
		frame.add(panel1.panel);
		//		panel2 already added
		frame.add(panel3.panel);
		frame.add(panel4.panel);
		frame.add(panel5.panel);
		//     returnHome.button already added
		
	}
	
	class ButtonListener implements ActionListener {
		
		public void actionPerformed( ActionEvent e ) {
			FindSuspectFrame homeScreen = new FindSuspectFrame(registry);
			frame.dispose();
		}
	}

}
