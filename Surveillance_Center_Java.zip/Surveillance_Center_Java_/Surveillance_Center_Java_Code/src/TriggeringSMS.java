import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class TriggeringSMS {
	
	JPanel panel;
	private JTextField searchNum;
	private JTextArea messages;
	JButton findButton;
	private String otherNum = "";
	Registry registry;
	Suspect s;
	
	TriggeringSMS(JFrame frame, Suspect susp, Registry reg) {
		
		registry = reg;
		s = susp;
		
		// SET UP PANEL
		panel = new JPanel();
		panel.setBackground(new Color(143, 47, 90));
        panel.setBounds(20, 140, 600, 160);
		
		// CREATE GRAPHIC ELEMENTS
		searchNum = new JTextField("");
		searchNum.setPreferredSize(new Dimension(100, 30));
		messages = new JTextArea("");
		messages.setPreferredSize(new Dimension(250, 150));
		findButton = new JButton("Find");
		findButton.setFocusPainted(false);
		
		// add elements to panel
		panel.add(searchNum);
		panel.add(messages);
		panel.add(findButton);
		
		// add panel to frame
		frame.add(panel);
		
		// add button action listener
		ButtonListener listener = new ButtonListener();
		findButton.addActionListener(listener);
		
	}
	
	
	class ButtonListener implements ActionListener {
		
		public void actionPerformed (ActionEvent e) {
			System.out.println("find sms");
			otherNum = searchNum.getText();
			messages.setText("");
			String allSMS = registry.getAllTrigMessagesWith(s, otherNum);
			messages.append(allSMS);
		}
	}
}
