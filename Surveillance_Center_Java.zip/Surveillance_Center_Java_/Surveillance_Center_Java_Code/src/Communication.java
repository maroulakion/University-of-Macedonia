
public abstract class Communication {

	String phone1, phone2;
	protected int day, month, year; 
	
	// CONSTRUCTOR
	public Communication (String phone1, String phone2, int day, int month, int year){
		this.phone1 = phone1;
		this.phone2 = phone2;
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	// GETTERS
	String getPhone1() {
		return phone1;
	}
	
	String getPhone2() {
		return phone2;
	}
	
	int getDay() {
		return day;
	}
	
	int getMonth() {
		return month;
	}
	
	int getYear() {
		return year;
	}
	
	abstract void printInfo();
	
}
