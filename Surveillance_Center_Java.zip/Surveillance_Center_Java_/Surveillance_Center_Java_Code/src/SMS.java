
public class SMS extends Communication {
	
	private String message;
	
	public SMS (String phone1, String phone2, int day, int month, int year, String message) {
		super(phone1, phone2, day, month, year);
		this.message = message;
	}
	
	String getMessage() {
		return message;
	}
	
	@Override
	void printInfo() {
		System.out.println("This SMS has the following info");
		System.out.println("Between " + phone1 + " --- " + phone2);
		System.out.println("on "+this.getYear()+"/"+this.getMonth()+"/"+this.getDay());
		System.out.println("Text: "+this.getMessage());
	}
	
}
