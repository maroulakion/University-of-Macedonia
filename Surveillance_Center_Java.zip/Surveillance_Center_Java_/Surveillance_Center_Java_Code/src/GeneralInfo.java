import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class GeneralInfo {
	
	JPanel panel;
	JTextField name;
	JTextField codeName;
	JTextArea numbers;
	
	GeneralInfo(Suspect s) {
		
		// SET UP PANEL
		panel = new JPanel();
		panel.setBackground(new Color(163, 67, 140));
        panel.setBounds(20, 20, 600, 110);
		
        //   	 CREATE GRAPHIC ELEMENTS
		name = new JTextField (s.getName());
		name.setPreferredSize(new Dimension(150, 30));
		
		codeName = new JTextField (s.getCodeName());
		codeName.setPreferredSize(new Dimension(120, 30));
		
		numbers = new JTextArea ();
		for (String n : s.getNumbers()) 
			numbers.append(n + "\n");
		numbers.setPreferredSize(new Dimension(100,100));
		
		// add elements to panel
		panel.add(name);
		panel.add(codeName);
		panel.add(numbers);
		
		
		
	}

}