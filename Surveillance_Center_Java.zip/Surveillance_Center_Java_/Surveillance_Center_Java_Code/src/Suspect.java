
import java.util.ArrayList;

public class Suspect {
	
	// CREATE ATTRIBUTES 
	
	// Suspect has name, codeName, countryBorn, targetCity
	// A suspect can use multiple phone numbers 
	// Every suspect is connected to other suspects 
 	// We consider suspects connected if they
	//   had contacted each other at least once
	private String name, codeName, countryBorn, targetCity;
	private ArrayList<String> numbers = new ArrayList<String>();
	private ArrayList<Suspect> partners = new ArrayList<Suspect>();
	//NEW for Assignment 3:
	private ArrayList<Suspect> suggPartners = new ArrayList<Suspect>();
	
	
	// CONSTRUCTOR
	Suspect (String name, String codeName, String countryBorn, String targetCity){
		this.name = name;
		this.codeName = codeName;
		this.countryBorn = countryBorn;
		this.targetCity = targetCity;
	}
	
	// GETTERS
	String getName() {
		return name;
	}
	
	String getCodeName() {
		return codeName;
	}
	
	String getCountryBorn() {
		return countryBorn;
	}
	
	ArrayList<String> getNumbers() {
		return numbers;
	}
	
	ArrayList<Suspect> getPartners() {
		return partners;
	}
	
	ArrayList<Suspect> getSuggPartners() {
		return suggPartners;
	}
	
	
	// METHODS
	
	// Add a number in the contacts of our suspect's list
	void addNumber (String phoneNumber) {
		numbers.add(phoneNumber);
	}
		
	
	// Check if a suspect is already enrolled in the "partners" list
	boolean isPartnerWith(Suspect possiblePartner) {
		for (Suspect partner : partners)
			if (partner.equals(possiblePartner)) 
				return true;
		return false;
				
	}
	
	//NEW for Assignment 3:
	//A generalization of the above 
	boolean existsOnList(ArrayList<Suspect> suspList) {
		for (Suspect susp : suspList)
			 if (this.equals(susp))
				 return true;
		return false;
	 }
	 
	
	// Checks if our suspect is linked to another suspect 
	boolean isConnectedTo(Suspect aSuspect) {
		for (Suspect partner : partners) 
			if (partner.equals(aSuspect))
				return true;
		return false;
	}
	
	
	// returns a list of partners two suspects have in common
	// e.g. if suspect A has {1,2,3} and Suspect B has {1,4,5,3}
	//      it shall return {1,3}
	ArrayList<Suspect> getCommonPartners(Suspect aSuspect) {
		ArrayList <Suspect> commonPartners = new ArrayList<Suspect>();
		
		for (Suspect partner : partners) 
			for (Suspect otherPartner : aSuspect.getPartners())
				if (partner.equals(otherPartner)) 
					if (!partner.existsOnList(commonPartners)){
						commonPartners.add(partner);
						break;
					}
		return commonPartners;
	}
	
	
	//print possible partners(name, codeName) of suspect
	//it shall add an "*" after codeName if 
	//   partners are born in the same country
	void printPartners() {
		//System.out.println(name + " is in partnership with");
		for (Suspect partner : partners)
			System.out.print(partner.getName() + ", " + partner.getCodeName());
	}
	
	String getAllPartners() {
		//System.out.println(name + " is in partnership with");
		String allPartners = "";
		for (Suspect part : partners) {
			//System.out.print(part.getName() + ", " + part.getCodeName());
			allPartners = allPartners + part.getName() + ", " + part.getCodeName() + "\n";
		}
		if (allPartners.equals(""))
			allPartners = "-- no partners --";
		return allPartners;
	}
	
	// NEW for Assignment 3
	// fetches the names of suggested partners
	String getAllSuggPartners() {
		//System.out.println(name + "'s suggested partners:");
		String allSugg = "";
		for (Suspect sugg : suggPartners) {
			//System.out.println(sugg.getName());
			allSugg = allSugg + sugg.getName() + ", " + sugg.getCodeName() + "\n";
		}
		if (allSugg.equals(""))
			allSugg = "-- no suggested partners --";
		return allSugg;
			
	}
	
	// NEW for Assignment 3
	// fetches all suspects coming from the same country as our object
	String getSuspectsFromSameCountry(Registry registry) {
		 //System.out.println("Suspects coming from " + this.getCountryBorn());
		 
		 ArrayList<Suspect> suspects =  registry.getSuspects();
		 
		 String suspSameCountry = "";
		 suspSameCountry = "Suspects coming from " + this.getCountryBorn() + "\n";
		 for (Suspect susp : suspects)
			 if (countryBorn.equals(susp.getCountryBorn()))
				 //if (!susp.equals(this)) --> If self not wanna be included
					 //System.out.println(susp.getName());
					 suspSameCountry = suspSameCountry + susp.getName() + "\n";
				 
		 return suspSameCountry;
	 }
	
	//  ARRAY LIST CHEATSHEET
		//  ArrayList<data_type> name = new ArrayList<data_type>();
		//  obj.add(data);
		//  obj.get(index);
		//  obj.set(index, new_data);
		//  obj.remove(index);
		//  obj.clear();
		//  obj.size();
		//  for (data_of_arraylist i : arraylist_name) 
		//  import java.util.Collections
		//  Collections.sort(arraylist_name); --> ascending order 
}
