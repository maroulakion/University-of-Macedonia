import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JTextArea;

public class SuspFromSameCountry {
	
	JPanel panel;
	JTextArea suspArea;
	
	SuspFromSameCountry(Suspect s, Registry registry) {
		
		// SET UP PANEL
		panel = new JPanel();
		panel.setBackground(new Color(113, 57, 70));
		panel.setBounds(20, 490, 600, 80);
		
		// CREATE GRAPHIC ELEMENTS
		String allSuspSameCountry = s.getSuspectsFromSameCountry(registry);
		suspArea = new JTextArea(allSuspSameCountry);
		suspArea.setPreferredSize(new Dimension(400, 70));
		
		// ADD ELEMENTS TO PANEL
		panel.add(suspArea);
		
	}
	
}
