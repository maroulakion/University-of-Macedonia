import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ButtonReturnToHomeScreen {
	
	JFrame frame;
	JPanel panel;
	JButton button;
	
	Registry registry;
	
	ButtonReturnToHomeScreen(JFrame frame, JPanel panel, Registry registry) {
		
		this.registry = registry;
		this.frame = frame;
		this.panel = panel;
		
		button = new JButton("Return to Home Screen");
		button.setPreferredSize(new Dimension(250, 30));
		button.setFocusPainted(false);
		
		panel.add(button);
		
		frame.add(panel);
		
		ButtonListener listener = new ButtonListener();
		button.addActionListener(listener);
	}
	
	class ButtonListener implements ActionListener {
		
		public void actionPerformed( ActionEvent e ) {
			FindSuspectFrame homeScreen = new FindSuspectFrame(registry);
			frame.dispose();
		}
	}

}
