import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class SuspectsPartners {
	
	JPanel panel;
	JLabel title;
	JTextArea partnersArea;
	
	SuspectsPartners(Suspect s) {
		
		// SET UP PANEL
		panel = new JPanel();
		panel.setBackground(new Color(123, 47, 40));
		panel.setBounds(20, 310, 600, 80);
		
		title = new JLabel("Partners");
		title.setForeground(Color.WHITE);
		title.setFont( new Font("Serif", Font.BOLD, 15));
		
		String allPartners = s.getAllPartners();
		partnersArea = new JTextArea(allPartners);
		partnersArea.setPreferredSize(new Dimension(250, 70));
		
		panel.add(title);
		panel.add(partnersArea);
		
	}
	
}
