import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FindSuspectFrame {
		
		private JFrame frame;
		private JButton findButton;
		private JButton returnHome;
		private JTextField searchBox;
		String suspWanted;		
		Registry registry;
		
		FindSuspectFrame(Registry registry) {
			
			this.registry = registry;
			
			// SET UP FRAME
			frame = new JFrame();
			frame.setLayout(null);
			//frame.getContentPane().setBackground(new Color(143, 196, 220));
			frame.getContentPane().setBackground(new Color(0, 255, 0));
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			//	 --> EXIT_ON_CLOSE: terminate program 
			frame.setSize(420, 250);
			frame.setTitle("Find suspect");
			
			
			//	 CREATE GRAPHIC ELEMENTS
			//	 	Search Box (waiting for suspects' name)
			searchBox = new JTextField("Please enter suspect's name");
			searchBox.setFont(new Font("Serif", Font.ITALIC, 20));
			searchBox.setForeground(Color.gray);
			searchBox.setPreferredSize( new Dimension(250, 40) );
			//	   	Find (suspect) button
			findButton = new JButton("Find");
			findButton.setPreferredSize( new Dimension(150, 40) );
			findButton.setFocusPainted(false);
			
			
			//   Add elements to panel
			JPanel panel = new JPanel();
			panel.setBounds(50, 50, 300, 150);
			panel.setBackground(new Color(73, 196, 210));
			panel.add(searchBox);
			panel.add(findButton);
			
			//  Add panel to frame
			frame.add(panel);
			
			frame.setVisible(true);
			
			ButtonListener listener = new ButtonListener();
			findButton.addActionListener(listener);
		}
		
		
		public String getSuspWanted() {
			return suspWanted;
		}
		
		public JFrame getFrame() {
			return frame;
		}
		
		class ButtonListener implements ActionListener {
			
			public void actionPerformed( ActionEvent e ) {
				
				suspWanted = searchBox.getText();

				boolean suspExists = false;
				Suspect s = new Suspect(suspWanted, "", "", "");				
				for (Suspect susp : registry.getSuspects()) {
					if (susp.getName().equals(s.getName())) {
						frame.setVisible(false);
						s = susp;
						suspExists = true;
						break;
					}
				}
				
				if (!suspExists) {
					System.out.println("nope");
					NotFoundFrame notFound =  new NotFoundFrame(s, registry);
				}
				else {
					System.out.println("found him");
					SuspectPage sPage =  new SuspectPage(s, registry);
				}
				frame.dispose();
			}
		}
		
}